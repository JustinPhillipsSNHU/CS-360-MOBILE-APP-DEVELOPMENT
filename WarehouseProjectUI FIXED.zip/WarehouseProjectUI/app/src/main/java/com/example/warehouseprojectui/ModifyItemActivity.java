package com.example.warehouseprojectui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ModifyItemActivity extends AppCompatActivity {

    private EditText editName, editDescription, editItemSoldValue, editItemPaidForValue, editItemQuantity, editItemWarehouseId;
    private ImageButton backButton;
    private Button submitButton, deleteButton, subtractQuantity, addQuantity;
    private ImageButton editItemIcon;

    private Integer itemId;
    private String itemName, itemDescription, itemWarehouseId;
    private double itemSoldValue, itemPaidForValue;
    private int itemQuantity;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // Initialize views
        backButton = findViewById(R.id.backbutton);
        editName = findViewById(R.id.editName);
        editDescription = findViewById(R.id.editDescription);
        editItemSoldValue = findViewById(R.id.editItemSoldValue);
        editItemPaidForValue = findViewById(R.id.editItemPaidForValue);
        editItemQuantity = findViewById(R.id.quantityType);
        editItemIcon = findViewById(R.id.imageButton2);
        submitButton = findViewById(R.id.submit);
        deleteButton = findViewById(R.id.adminDeleteButton);
        subtractQuantity = findViewById(R.id.subtractQuantity);
        addQuantity = findViewById(R.id.addQuantity);

        // Retrieve item data from Intent
        itemId = getIntent().getIntExtra("ITEM_ID", -1);
        itemName = getIntent().getStringExtra("ITEM_NAME");
        itemDescription = getIntent().getStringExtra("ITEM_DESCRIPTION");
        itemSoldValue = getIntent().getDoubleExtra("ITEM_SOLD_VALUE", 0.0);
        itemPaidForValue = getIntent().getDoubleExtra("ITEM_PAID_FOR_VALUE", 0.0);
        itemQuantity = getIntent().getIntExtra("ITEM_QUANTITY", 0);
        itemWarehouseId = getIntent().getStringExtra("ITEM_WAREHOUSE_ID");

        // Set initial values
        Log.d("ModifyItemActivity", "Item ID: " + itemId);
        Log.d("ModifyItemActivity", "Item Name: " + itemName);
        editName.setText(itemName);
        Log.d("ModifyItemActivity", "Item Description: " + itemDescription);
        editDescription.setText(itemDescription);
        Log.d("ModifyItemActivity", "Item Sold Value: " + itemSoldValue);
        editItemSoldValue.setText(String.valueOf(itemSoldValue));
        Log.d("ModifyItemActivity", "Item Paid For Value: " + itemPaidForValue);
        editItemPaidForValue.setText(String.valueOf(itemPaidForValue));
        Log.d("ModifyItemActivity", "Item Quantity: " + itemQuantity);
        editItemQuantity.setText(String.valueOf(itemQuantity));

        // Back button click listener
        backButton.setOnClickListener(v -> finish());

        // Submit button click listener
        submitButton.setOnClickListener(v -> updateItem());

        // Delete button click listener
        deleteButton.setOnClickListener(v -> deleteItem());

        // Quantity buttons click listeners
        subtractQuantity.setOnClickListener(v -> updateQuantity(-1));
        addQuantity.setOnClickListener(v -> updateQuantity(1));
    }

    private void updateItem() {
        Integer id = itemId;
        String name = editName.getText().toString();
        String description = editDescription.getText().toString();
        double soldValue = Double.parseDouble(editItemSoldValue.getText().toString());
        double paidForValue = Double.parseDouble(editItemPaidForValue.getText().toString());
        int quantity = Integer.parseInt(editItemQuantity.getText().toString());
        int icon = 0; // Placeholder icon

        boolean isUpdated = ItemTableInterface.updateItem(id, name, description, soldValue, paidForValue, quantity, icon);

        if (isUpdated) {
            Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        boolean isDeleted = ItemTableInterface.deleteItem(itemId);

        if (isDeleted) {
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateQuantity(int delta) {
        int currentQuantity = Integer.parseInt(editItemQuantity.getText().toString());
        int newQuantity = currentQuantity + delta;
        if (newQuantity >= 0) {
            editItemQuantity.setText(String.valueOf(newQuantity));
        } else {
            Toast.makeText(this, "Quantity can't be less than zero", Toast.LENGTH_SHORT).show();
        }
    }
}
