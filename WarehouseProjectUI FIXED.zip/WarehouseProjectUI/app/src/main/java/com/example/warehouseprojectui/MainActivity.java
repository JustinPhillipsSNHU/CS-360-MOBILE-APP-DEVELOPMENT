package com.example.warehouseprojectui;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    // Login information
    private EditText editUsername, editPassword, editWarehouseID;
    private Button loginButton;
    private UserTableInterface userTableInterface;
    public static String active_warehouse;
    public static String active_role;
    public static SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        editWarehouseID = findViewById(R.id.editWarehouseID);
        loginButton = findViewById(R.id.loginButton);

        database = openOrCreateDatabase("WarehouseDB", MODE_PRIVATE, null);
        userTableInterface = new UserTableInterface();
        final String TAG = "MainActivity";

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();
                String warehouseID = editWarehouseID.getText().toString();
                active_warehouse = warehouseID;
                if (username.isEmpty() || password.isEmpty() || warehouseID.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // If the warehouse ID exists as a name in the SQLite database,
                    // See if the username exists in that warehouse's database.
                    // Then see if the password is right.
                    Cursor validLogIn = UserTableInterface.authenticateUser(username, password);
                    Cursor userInWarehouse = UserTableInterface.getUser(username);
                    Boolean warehouseExists = UserTableInterface.getWarehouse(warehouseID);
                    if (validLogIn.getCount() > 0) {
                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        // User logged in.
                        // Switch to the ViewListActivity
                        // Switch to the ViewListActivity
                        Log.d(TAG, "Creating intent");
                        Intent intent = new Intent(MainActivity.this, ViewListActivity.class);
                        Log.d(TAG, "Setting intent extras");
                        Log.d(TAG, "warehouseID: " + warehouseID);
                        intent.putExtra("accessedWarehouseId", warehouseID);
                        Log.d(TAG, "Setting username");
                        Log.d(TAG, "username: " + username);
                        intent.putExtra("username", username);
                        String role;
                        try {
                            role = UserTableInterface.getRoleName(username);
                        } catch (Exception e) {
                            role = "user";
                        }
                        Log.d(TAG, "Setting role");
                        Log.d(TAG, "role: " + role);
                        intent.putExtra("role", role);
                        active_role = role;
                        Log.d(TAG, "Launching ViewListActivity");
                        startActivity(intent);
                    }
                    else if (userInWarehouse.getCount() > 0) {
                        // If the warehouse ID exists and the name is in the database,
                        // The user failed to log in.
                        Toast.makeText(MainActivity.this, "Login failed, please check password.", Toast.LENGTH_SHORT).show();
                    }
                    else if (warehouseExists) {
                        // If the warehouse ID exists and the name is not in the database,
                        // The user failed to log in.
                        Toast.makeText(MainActivity.this, "Login failed, please contact warehouse admin.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        // If the warehouse ID does not exist, then it should be created,
                        // with a new user.
                        Toast.makeText(MainActivity.this, "Created new warehouse", Toast.LENGTH_SHORT).show();
                        userTableInterface.createUser(username, password, "owner");
                        // Switch to the ViewListActivity
                        Log.d(TAG, "Creating intent");
                        Intent intent = new Intent(MainActivity.this, ViewListActivity.class);
                        Log.d(TAG, "Setting intent extras");
                        Log.d(TAG, "warehouseID: " + warehouseID);
                        intent.putExtra("accessedWarehouseId", warehouseID);
                        Log.d(TAG, "Setting username");
                        Log.d(TAG, "username: " + username);
                        intent.putExtra("username", username);
                        String role;
                        try {
                            role = userTableInterface.getRoleName(username);
                        } catch (Exception e) {
                            role = "owner";
                        }
                        Log.d(TAG, "Setting role");
                        Log.d(TAG, "role: " + role);
                        intent.putExtra("role", role);
                        active_role = role;
                        Log.d(TAG, "Launching ViewListActivity");
                        startActivity(intent);
                    }
                }
            }
        });
    }
}