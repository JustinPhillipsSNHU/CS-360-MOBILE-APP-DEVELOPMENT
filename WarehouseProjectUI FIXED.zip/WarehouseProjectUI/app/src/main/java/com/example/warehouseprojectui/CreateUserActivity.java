package com.example.warehouseprojectui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CreateUserActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Switch toggleActive, toggleAccess, toggleModifyItems, toggleDeleteItems, toggleModifyUsers, toggleDeleteUsers;
    private Button saveUser;
    private ImageButton backButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_user); // Reusing the same layout

        // Initialize views
        backButton = findViewById(R.id.backbutton);
        editUsername = findViewById(R.id.editUserUserName);
        editPassword = findViewById(R.id.editUserPassword);
        toggleActive = findViewById(R.id.toggleActive);
        toggleAccess = findViewById(R.id.toggleAccess);
        toggleModifyItems = findViewById(R.id.toggleModifyItems);
        toggleDeleteItems = findViewById(R.id.toggleDeleteItem);
        toggleModifyUsers = findViewById(R.id.toggleModifyUser);
        toggleDeleteUsers = findViewById(R.id.toggleDeleteUser);
        saveUser = findViewById(R.id.saveUser);

        // Back button click listener
        backButton.setOnClickListener(v -> finish());

        // Save button click listener
        saveUser.setOnClickListener(v -> createUser());
    }

    private void createUser() {
        String username = editUsername.getText().toString();
        String password = editPassword.getText().toString();
        String role = "user"; // Default role
        String permissions = getPermissions();

        boolean isCreated = UserTableInterface.createUser(username, password, role);

        if (isCreated) {
            Toast.makeText(this, "User created successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to create user", Toast.LENGTH_SHORT).show();
        }
    }

    private String getPermissions() {
        // Get permissions based on the toggles
        StringBuilder permissions = new StringBuilder();
        if (toggleModifyItems.isChecked()) permissions.append("MODIFY_ITEMS,");
        if (toggleDeleteItems.isChecked()) permissions.append("DELETE_ITEMS,");
        if (toggleModifyUsers.isChecked()) permissions.append("MODIFY_USERS,");
        if (toggleDeleteUsers.isChecked()) permissions.append("DELETE_USERS,");
        // Remove the last comma
        if (permissions.length() > 0) permissions.setLength(permissions.length() - 1);
        return permissions.toString();
    }
}
