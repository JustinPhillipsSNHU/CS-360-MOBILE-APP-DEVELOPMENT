package com.example.warehouseprojectui;

import java.util.ArrayList;

public class User {
    private int id;
    private String username;
    private String password;
    private String warehouseId;
    private String role;
    private ArrayList permissions;

    // Constructor
    public User(int id, String username, String password, String warehouseId, String role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.warehouseId = warehouseId;
        this.role = role;
    }

    // Getters and Setters
    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getWarehouseId() {
        return this.warehouseId;
    }

    public void setWarehouseId(String warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public ArrayList getPermissions() {
        return this.permissions;
    }

    public void addPermission(String permission) {
        permissions.add(permission);
    }

    public void removePermission(String permission) {
        permissions.remove(permission);
    }

    public void setPermissions(ArrayList permissions) {
        this.permissions = permissions;
    }
}
