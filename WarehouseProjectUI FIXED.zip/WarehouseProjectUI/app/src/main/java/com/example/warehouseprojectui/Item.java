package com.example.warehouseprojectui;

public class Item {
    private int id;
    private String name;
    private String description;
    private double sold_value; // Sold it for
    private double paid_for_value; // Paid for it
    private int quantity;
    private int icon;
    private String warehouseId;

    // Constructor
    public Item(int id, String name, String description, double sold_value, double paid_for_value, int quantity, int icon, String warehouseId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.sold_value = sold_value;
        this.paid_for_value = paid_for_value;
        this.quantity = quantity;
        this.icon = icon;
        this.warehouseId = warehouseId;
    }

    // Getters and Setters
    public String getWarehouseId() {
        return this.warehouseId;
    }

    public void setWarehouseId(String warehouseId) {
        this.warehouseId = warehouseId;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getSoldValue() {
        return this.sold_value;
    }

    public void setsoldValue(double sold_value) {
        this.sold_value = sold_value;
    }

    public double getPaidForValue() {
        return this.paid_for_value;
    }

    public void setPaidForValue(double paid_for_value) {
        this.paid_for_value = paid_for_value;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getIcon() {
        return this.icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
