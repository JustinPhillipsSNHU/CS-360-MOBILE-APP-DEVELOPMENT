package com.example.warehouseprojectui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CreateItemActivity extends AppCompatActivity {

    private EditText editName, editDescription, editItemSoldValue, editItemPaidForValue, editItemQuantity, editItemWarehouseId;
    private Button saveButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item); // Reusing the same layout

        // Initialize views
        editName = findViewById(R.id.editName);
        editDescription = findViewById(R.id.editDescription);
        editItemSoldValue = findViewById(R.id.editItemSoldValue);
        editItemPaidForValue = findViewById(R.id.editItemPaidForValue);
        editItemQuantity = findViewById(R.id.quantityType);
        saveButton = findViewById(R.id.submit);

        // Set the save button click listener
        saveButton.setOnClickListener(v -> createItem());
    }

    private void createItem() {
        String name = editName.getText().toString();
        String description = editDescription.getText().toString();
        double soldValue = Double.parseDouble(editItemSoldValue.getText().toString());
        double paidForValue = Double.parseDouble(editItemPaidForValue.getText().toString());
        int quantity = Integer.parseInt(editItemQuantity.getText().toString());
        int icon = 0; // Placeholder for item icon

        boolean isCreated = ItemTableInterface.createItem(name, description, soldValue, paidForValue, quantity, icon);

        if (isCreated) {
            Toast.makeText(this, "Item created successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to create item", Toast.LENGTH_SHORT).show();
        }
    }
}
