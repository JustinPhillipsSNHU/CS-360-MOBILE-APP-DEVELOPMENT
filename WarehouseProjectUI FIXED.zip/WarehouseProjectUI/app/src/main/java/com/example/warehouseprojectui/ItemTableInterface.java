package com.example.warehouseprojectui;


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemTableInterface {
    // Define the Item table
    // Using the item object
    /*    private int id;
    private String name;
    private String description;
    private double sold_value; // Sold it for
    private double paid_for_value; // Paid for it
    private int quantity;
    private int icon;
    private String warehouseId;
     */

    static String active_warehouse = MainActivity.active_warehouse;
    static SQLiteDatabase db = MainActivity.database;

    // Define the methods for the Item table
    static final String TABLE_NAME = "items";
    static final String COLUMN_ID = "id";
    static final String COLUMN_NAME = "item_name";
    static final String COLUMN_DESCRIPTION = "item_description";
    static final String COLUMN_SOLD_VALUE = "item_sold_value";
    static final String COLUMN_PAID_FOR_VALUE = "item_paid_for_value";
    static final String COLUMN_QUANTITY = "item_quantity";
    static final String COLUMN_ICON = "item_icon";
    static final String COLUMN_WAREHOUSE_ID = "warehouse_id";


    public ItemTableInterface() {
        onCreate();
    }

    public static void onCreate() {
        active_warehouse = MainActivity.active_warehouse;
        // Create the table
        String createTableSQL = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " + COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_SOLD_VALUE + " REAL, " + COLUMN_PAID_FOR_VALUE + " REAL, " +
                COLUMN_QUANTITY + " INTEGER, " + COLUMN_ICON + " INTEGER, " +
                COLUMN_WAREHOUSE_ID + " TEXT)";
        db.execSQL(createTableSQL);

        // Insert a dummy item
        createItem("Null Item", "No Description", 0.0, 0.0, 0, 0);
    }

    public void onUpgrade(int oldVersion, int newVersion) {
        // Handle database upgrades
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate();
    }

    // CREATE
    public static boolean createItem(String name, String description, double soldValue, double paidForValue, int quantity, int icon) {
        active_warehouse = MainActivity.active_warehouse;
        ContentValues values = new ContentValues();
        if (name != null) {
            values.put(COLUMN_NAME, name);
        } else {
            values.put(COLUMN_NAME, "Null Item");
        }
        if (description != null) {
            values.put(COLUMN_DESCRIPTION, description);
        } else {
            values.put(COLUMN_DESCRIPTION, "No description");
        }
        if (soldValue >= 0) {
            values.put(COLUMN_SOLD_VALUE, soldValue);
        } else {
            values.put(COLUMN_SOLD_VALUE, 0.0);
        }
        if (paidForValue >= 0) {
            values.put(COLUMN_PAID_FOR_VALUE, paidForValue);
        } else {
            values.put(COLUMN_PAID_FOR_VALUE, 0.0);
        }
        if (quantity >= 0) {
            values.put(COLUMN_QUANTITY, quantity);
        } else {
            values.put(COLUMN_QUANTITY, 0);
        }
        if (icon >= 0) {
            values.put(COLUMN_ICON, icon);
        } else {
            values.put(COLUMN_ICON, 0);
        }
        values.put(COLUMN_WAREHOUSE_ID, active_warehouse);
        try {
            db.insertOrThrow(TABLE_NAME, null, values);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // READ
    public static Cursor getItem(String name) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_NAME + "=? AND " + COLUMN_WAREHOUSE_ID + " = ?";
        return db.rawQuery(query, new String[]{name, active_warehouse});
    }

    public static Cursor getItem(Integer id) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + "=? AND " + COLUMN_WAREHOUSE_ID + " = ?";
        return db.rawQuery(query, new String[]{String.valueOf(id), active_warehouse});
    }

    // Get warehouse exists
    public static boolean getWarehouse(String warehouseId) {
        // Create the table
        String createTableSQL = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " + COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_SOLD_VALUE + " REAL, " + COLUMN_PAID_FOR_VALUE + " REAL, " +
                COLUMN_QUANTITY + " INTEGER, " + COLUMN_ICON + " INTEGER, " +
                COLUMN_WAREHOUSE_ID + " TEXT)";
        db.execSQL(createTableSQL);

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_WAREHOUSE_ID + " = ?";
        Cursor result = db.rawQuery(query, new String[]{warehouseId});
        boolean valid = result != null && result.moveToFirst();
        assert result != null;
        result.close();
        return valid;
    }

    // Get all items in the warehouse
    public static List<Item> getAllItems() {
        active_warehouse = MainActivity.active_warehouse;
        List<Item> items = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_WAREHOUSE_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{active_warehouse});
        if (cursor.moveToFirst()) {
            do {
                try {
                    int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                    String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                    String description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION));
                    double soldValue = cursor.getDouble(cursor.getColumnIndex(COLUMN_SOLD_VALUE));
                    double paidForValue = cursor.getDouble(cursor.getColumnIndex(COLUMN_PAID_FOR_VALUE));
                    int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY));
                    int icon = cursor.getInt(cursor.getColumnIndex(COLUMN_ICON));
                    String warehouseId = cursor.getString(cursor.getColumnIndex(COLUMN_WAREHOUSE_ID));
                    items.add(new Item(id, name, description, soldValue, paidForValue, quantity, icon, warehouseId));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());
        } else {
            // Handle the case where no items are found
            // Create a dummy item and add it to the list
            Item dummyItem = new Item(0, "Null Item", "No Description", 0.0, 0.0, 0, 0, active_warehouse);
            items.add(dummyItem);
        }
        cursor.close();
        return items;
    }


    // UPDATE
    public static boolean updateItem(int id, String name, String description, double soldValue, double paidForValue, int quantity, int icon) {
        active_warehouse = MainActivity.active_warehouse;
        ContentValues values = new ContentValues();

        if (name != null) {
            values.put(COLUMN_NAME, name);
        }
        if (description != null) {
            values.put(COLUMN_DESCRIPTION, description);
        }
        if (soldValue >= 0) {
            values.put(COLUMN_SOLD_VALUE, soldValue);
        }
        if (paidForValue >= 0) {
            values.put(COLUMN_PAID_FOR_VALUE, paidForValue);
        }
        if (quantity >= 0) {
            values.put(COLUMN_QUANTITY, quantity);
        }
        if (icon >= 0) {
            values.put(COLUMN_ICON, icon);
        }

        String whereClause = COLUMN_ID + " = ? AND " + COLUMN_WAREHOUSE_ID + " = ?";
        String[] whereArgs = {String.valueOf(id), active_warehouse};

        int result = db.update(TABLE_NAME, values, whereClause, whereArgs);
        if (result > 0) {
            // Send out a notification and return true
            NotificationsActivity.sendSmsItemMod(String.valueOf(getItem(id).getColumnIndex(COLUMN_NAME)));
            return true;
        }
        return false;
    }


    // DELETE
    public static boolean deleteItem(int id) {
        active_warehouse = MainActivity.active_warehouse;
        String whereClause = COLUMN_ID + " = ? AND " + COLUMN_WAREHOUSE_ID + " = ?";
        String[] whereArgs = {String.valueOf(id), active_warehouse};

        int result = db.delete(TABLE_NAME, whereClause, whereArgs);
        if (result > 0) {
            // Send out a notification and return true
            NotificationsActivity.sendSmsItemDel(String.valueOf(getItem(id).getColumnIndex(COLUMN_NAME)));
            return true;
        }
        return false;
    }
}
