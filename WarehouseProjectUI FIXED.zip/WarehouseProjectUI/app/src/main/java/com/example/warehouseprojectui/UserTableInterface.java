package com.example.warehouseprojectui;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

// TODO: Items modified breaks the app. Leave the notification stuff in for now.

public class UserTableInterface {
    // Define the User table
    // Using the user object
    /*    private int id;
    private String username;
    private String password;
    private String warehouseId;
    private String role;
    private ArrayList permissions;*/

    static String active_warehouse = MainActivity.active_warehouse;
    static SQLiteDatabase db = MainActivity.database;

    // Let's construct the table with its columns
    static final String TABLE_NAME = "users";
    static final String COL_ID = "id";
    static final String COL_USERNAME = "username";
    static final String COL_PASSWORD = "password";
    static final String COL_WAREHOUSE_ID = "warehouse_id";
    static final String COL_ROLE = "role";
    static final String COL_PERMISSIONS = "permissions";

    public UserTableInterface() {
        onCreate();
    }

    public static void onCreate() {
        active_warehouse = MainActivity.active_warehouse;
        // Create table SQL query
        String createTableSQL = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT, " +
                COL_WAREHOUSE_ID + " TEXT," +
                COL_ROLE + " TEXT," +
                COL_PERMISSIONS + " TEXT)";
        db.execSQL(createTableSQL);

        // Insert a dummy
        createUser("Null User", "password");
    }

    // Handle updates
    public static void onUpgrade(int oldVersion, int newVersion) {
        active_warehouse = MainActivity.active_warehouse;
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate();
    }

    // Define the methods for the User table
    // Create
    public static boolean createUser(String username, String password, String role) {
        active_warehouse = MainActivity.active_warehouse;
        ContentValues values = new ContentValues();
        if (username != null) {
            values.put(COL_USERNAME, username);
        } else {
            values.put(COL_USERNAME, "Null User");
        }
        if (password != null) {
            values.put(COL_PASSWORD, password);
        } else {
            values.put(COL_PASSWORD, "password");
        }
        values.put(COL_WAREHOUSE_ID, active_warehouse);
        if (role != null) {
            values.put(COL_ROLE, role);
        } else {
            values.put(COL_ROLE, "user");
        }
        values.put(COL_PERMISSIONS, "[]");
        try {
            db.insert(TABLE_NAME, null, values);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    // Default role is user
    public static boolean createUser(String username, String password) {
        active_warehouse = MainActivity.active_warehouse;
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        values.put(COL_WAREHOUSE_ID, active_warehouse);
        values.put(COL_ROLE, "user");
        values.put(COL_PERMISSIONS, "");
        try {
            db.insert(TABLE_NAME, null, values);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    // Read
    // Get the individual user with a query
    public static Cursor getUser(String username) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_USERNAME + " = ? AND " + COL_WAREHOUSE_ID + " = ?";
        return db.rawQuery(query, new String[]{username, active_warehouse});
    }

    // Authenticate the username and password
    public static Cursor authenticateUser(String username, String password) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ? AND " + COL_WAREHOUSE_ID + " = ?" ;
        return db.rawQuery(query, new String[]{username, password, active_warehouse});
    }

    // Authenticate the username, password, and warehouse
    public static Cursor authenticateUser(String username, String password, String warehouseId) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ? AND " + COL_WAREHOUSE_ID + " = ?";
        return db.rawQuery(query, new String[]{username, password, warehouseId});
    }

    public static String getRoleName(String username) {
        active_warehouse = MainActivity.active_warehouse;
        String query = "SELECT " + COL_ROLE + " FROM " + TABLE_NAME + " WHERE " + COL_USERNAME + " = ? AND " + COL_WAREHOUSE_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, active_warehouse});
        if (cursor.moveToFirst()) {
            return cursor.getString(cursor.getColumnIndex(COL_ROLE));
        }
        return null;
    }

    // Get all users in the warehouse
    public static List<User> getAllUsers() {
        active_warehouse = MainActivity.active_warehouse;
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_WAREHOUSE_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{active_warehouse});
        if (cursor.moveToFirst()) {
            do {
                try {
                    int id = cursor.getInt(cursor.getColumnIndex(COL_ID));
                    String username = cursor.getString(cursor.getColumnIndex(COL_USERNAME));
                    String password = cursor.getString(cursor.getColumnIndex(COL_PASSWORD));
                    String warehouseId = cursor.getString(cursor.getColumnIndex(COL_WAREHOUSE_ID));
                    String role = cursor.getString(cursor.getColumnIndex(COL_ROLE));
                    String permissions = cursor.getString(cursor.getColumnIndex(COL_PERMISSIONS));
                    String[] permissions_array = permissions.split(",");

                    users.add(new User(id, username, password, warehouseId, role));
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());
        } else {
            // Handle the case where no users are found
            // Create a dummy user and add it to the list
            User dummyUser = new User(0, "Null User", "password", active_warehouse, "user");
            users.add(dummyUser);
        }
        cursor.close();
        return users;
    }

    // Get the warehouse
    public static boolean getWarehouse(String warehouseId) {
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_WAREHOUSE_ID + " = ?";
        Cursor result = db.rawQuery(query, new String[]{warehouseId});
        boolean valid = result != null && result.moveToFirst();
        assert result != null;
        result.close();
        return valid;
    }

    // Update
    public static boolean updateUser(String username, String password, String role, String[] permissions) {
        active_warehouse = MainActivity.active_warehouse;
        ContentValues values = new ContentValues();
        if (username != null) {
            values.put(COL_USERNAME, username);
        }
        if (password != null) {
            values.put(COL_PASSWORD, password);
        }
        if (role != null) {
            values.put(COL_ROLE, role);
        }
        if (permissions != null) {
            values.put(COL_PERMISSIONS, Arrays.toString(permissions));
        }
        String whereClause = COL_USERNAME + " = ? AND " + COL_WAREHOUSE_ID + " = ?";
        String[] whereArgs = {username, active_warehouse};
        int result = db.update(TABLE_NAME, values, whereClause, whereArgs);
        if (result > 0) {
            // Send out a notification and return true
            NotificationsActivity.sendSmsUserMod(username);
            return true;
        }
        return false;
    }

    // Delete
    public static boolean deleteUser(String username) {
        active_warehouse = MainActivity.active_warehouse;
        String whereClause = COL_USERNAME + " = ? AND " + COL_WAREHOUSE_ID + " = ?";
        String[] whereArgs = {username, active_warehouse};
        int result = db.delete(TABLE_NAME, whereClause, whereArgs);
        if (result > 0) {
            // Send out a notification and return true
            NotificationsActivity.sendSmsUserDel(username);
            return true;
        }
        return false;
    }
}
