package com.example.warehouseprojectui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ItemCardAdapter extends RecyclerView.Adapter<ItemCardAdapter.ItemViewHolder> {

    private Context context;
    private List<Item> itemList;

    public ItemCardAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.template_item_card, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.nameView.setText(item.getName());
        holder.quantityView.setText(String.valueOf(item.getQuantity()));
        holder.imageButton.setImageResource(item.getIcon());

        holder.imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ModifyItemActivity.class);
                intent.putExtra("ITEM_ID", item.getId());
                intent.putExtra("ITEM_NAME", item.getName());
                intent.putExtra("ITEM_DESCRIPTION", item.getDescription());
                intent.putExtra("ITEM_SOLD_VALUE", item.getSoldValue());
                intent.putExtra("ITEM_PAID_FOR_VALUE", item.getPaidForValue());
                intent.putExtra("ITEM_QUANTITY", item.getQuantity());
                intent.putExtra("ITEM_ICON", item.getIcon());
                intent.putExtra("ITEM_WAREHOUSE_ID", item.getWarehouseId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView nameView, quantityView;
        ImageButton imageButton;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            nameView = itemView.findViewById(R.id.nameView);
            quantityView = itemView.findViewById(R.id.quantityView);
            imageButton = itemView.findViewById(R.id.imageButton);
        }
    }
}
