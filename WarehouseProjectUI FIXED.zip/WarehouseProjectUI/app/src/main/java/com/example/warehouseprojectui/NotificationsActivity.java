package com.example.warehouseprojectui;

import static android.telephony.SubscriptionManager.getDefaultSubscriptionId;
import static java.lang.Integer.parseInt;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.telephony.SmsManager;

public class NotificationsActivity extends AppCompatActivity {

    private EditText notiItemQty, smsInput;
    private static Switch toggleNotiUserDel;
    private static Switch toggleNotiItemDel;
    private static Switch toggleNotiUserMod;
    private static Switch toggleNotiItemMod;
    private Button saveSMS;
    private static SharedPreferences sharedPreferences;

    private static final String PREFS_NAME = "NotificationsPrefs";
    private static final String NOTI_USER_DEL = "notiUserDel";
    private static final String NOTI_ITEM_DEL = "notiItemDel";
    private static final String NOTI_USER_MOD = "notiUserMod";
    private static final String NOTI_ITEM_MOD = "notiItemMod";
    private static final String NOTI_ITEM_QTY = "notiItemQty";
    private static final String SMS_NUMBER = "smsNumber";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        // Initialize views
        notiItemQty = findViewById(R.id.notiItemQty);
        smsInput = findViewById(R.id.smsInput);
        toggleNotiUserDel = findViewById(R.id.toggleNotiUserDel);
        toggleNotiItemDel = findViewById(R.id.toggleNotiItemDel);
        toggleNotiUserMod = findViewById(R.id.toggleNotiUserMod);
        toggleNotiItemMod = findViewById(R.id.toggleNotiItemMod);
        saveSMS = findViewById(R.id.saveSMS);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load saved settings
        loadSettings();

        // Save button click listener
        saveSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });
    }

    private void loadSettings() {
        toggleNotiUserDel.setChecked(sharedPreferences.getBoolean(NOTI_USER_DEL, false));
        toggleNotiItemDel.setChecked(sharedPreferences.getBoolean(NOTI_ITEM_DEL, false));
        toggleNotiUserMod.setChecked(sharedPreferences.getBoolean(NOTI_USER_MOD, false));
        toggleNotiItemMod.setChecked(sharedPreferences.getBoolean(NOTI_ITEM_MOD, false));
        notiItemQty.setText(sharedPreferences.getString(NOTI_ITEM_QTY, "20"));
        smsInput.setText(sharedPreferences.getString(SMS_NUMBER, ""));
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(NOTI_USER_DEL, toggleNotiUserDel.isChecked());
        editor.putBoolean(NOTI_ITEM_DEL, toggleNotiItemDel.isChecked());
        editor.putBoolean(NOTI_USER_MOD, toggleNotiUserMod.isChecked());
        editor.putBoolean(NOTI_ITEM_MOD, toggleNotiItemMod.isChecked());
        editor.putString(NOTI_ITEM_QTY, notiItemQty.getText().toString());
        editor.putString(SMS_NUMBER, smsInput.getText().toString());
        editor.apply();
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private static void initializeSharedPreferences(Context context) {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences("NotificationsPrefs", Context.MODE_PRIVATE);
        }
    }

    private static void sendSMS(String message) {
        String smsNumber = sharedPreferences.getString("SMS_NUMBER", "");
        if (!smsNumber.isEmpty()) {
            SmsManager smsManager = SmsManager.getSmsManagerForSubscriptionId(getDefaultSubscriptionId());
            smsManager.sendTextMessage(smsNumber, null, message, null, null);
        }
    }

    public static void sendSmsUserDel(String username) {
        if (sharedPreferences.getBoolean("notiUserDel", true)) {
            String message = "User " + username + " has been deleted.";
            sendSMS(message);
        }
    }

    public static void sendSmsItemDel(String itemName) {
        if (sharedPreferences.getBoolean("notiItemDel", true)) {
            String message = "Item " + itemName + " has been deleted.";
            sendSMS(message);
        }
    }

    public static void sendSmsUserMod(String username) {
        if (sharedPreferences.getBoolean("notiUserMod", true)) {
            String message = "User " + username + " has been modified.";
            sendSMS(message);
        }
    }

    public static void sendSmsItemMod(String itemName) {
        return;
        // Todo: This is broken right now.
        /*if (sharedPreferences.getBoolean("notiItemMod", true)) {
            String message = "Item " + itemName + " has been modified.";
            sendSMS(message);
        }*/
    }

    public static void sendSmsItemQty(Context context, String itemName, int qty) {
        initializeSharedPreferences(context);
        int threshold = Integer.parseInt(sharedPreferences.getString("notiItemQty", "20"));
        if (Math.abs(qty) >= threshold) {
            String message = "Item " + itemName + " inventory adjusted by " + qty + " units.";
            sendSMS(message);
        }
    }
}