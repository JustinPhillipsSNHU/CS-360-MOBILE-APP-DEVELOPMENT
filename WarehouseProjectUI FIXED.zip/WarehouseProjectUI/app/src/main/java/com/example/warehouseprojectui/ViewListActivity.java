package com.example.warehouseprojectui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ViewListActivity extends AppCompatActivity {

    private RecyclerView itemsList;
    private ItemCardAdapter itemCardAdapter;
    private Button adminSwitchButton;
    private FloatingActionButton addNewButton;
    private FloatingActionButton settingsButton;
    private boolean isItemView = true; // Flag to toggle between item and user view

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);

        // Load the items and users database by creating them
        if (ItemTableInterface.getWarehouse(MainActivity.active_warehouse) == false) {
            ItemTableInterface.onCreate();
        }

        itemsList = findViewById(R.id.itemsList);
        adminSwitchButton = findViewById(R.id.adminSwitchButton);
        addNewButton = findViewById(R.id.addNewButton);
        settingsButton = findViewById(R.id.settingsButton);
        itemsList.setLayoutManager(new LinearLayoutManager(this));

        // Load initial view
        if (isItemView) {
            loadItems();
        } else {
            loadUsers();
        }

        // Set the switch button listener
        adminSwitchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isItemView) {
                    // Switch to user view
                    loadUsers();
                } else {
                    // Switch to item view
                    loadItems();
                }
                isItemView = !isItemView; // Toggle the view flag
            }
        });

        // Set the add new button listener
        addNewButton.setOnClickListener(v -> {
            if (isItemView) {
                Intent intent = new Intent(ViewListActivity.this, CreateItemActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(ViewListActivity.this, CreateUserActivity.class);
                startActivity(intent);
            }
        });

        // Set the settings button listener
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(ViewListActivity.this, NotificationsActivity.class);
            startActivity(intent);
        });
    }

    private void loadItems() {
        List<Item> itemList = ItemTableInterface.getAllItems();
        itemCardAdapter = new ItemCardAdapter(this, itemList);
        itemsList.setAdapter(itemCardAdapter);
    }

    private void loadUsers() {
        // You will need to create a UserCardAdapter and get user data similar to items
        // For now, this is a placeholder
        List<User> userList = UserTableInterface.getAllUsers(); // Create UserTableInterface class and method
        UserCardAdapter userCardAdapter = new UserCardAdapter(this, userList); // Create UserCardAdapter class
        itemsList.setAdapter(userCardAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload the list to reflect any changes made in CreateItemActivity
        if (isItemView) {
            loadItems();
        } else {
            loadUsers();
        }
    }
}
