package com.example.warehouseprojectui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class ModifyUserActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Switch toggleActive, toggleAccess, toggleModifyItems, toggleDeleteItems, toggleModifyUsers, toggleDeleteUsers;
    private Button saveUser, deleteUser;
    private ImageButton backButton;

    private String originalUsername;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_user);

        // Initialize views
        backButton = findViewById(R.id.backbutton);
        editUsername = findViewById(R.id.editUserUserName);
        editPassword = findViewById(R.id.editUserPassword);
        toggleActive = findViewById(R.id.toggleActive);
        toggleAccess = findViewById(R.id.toggleAccess);
        toggleModifyItems = findViewById(R.id.toggleModifyItems);
        toggleDeleteItems = findViewById(R.id.toggleDeleteItem);
        toggleModifyUsers = findViewById(R.id.toggleModifyUser);
        toggleDeleteUsers = findViewById(R.id.toggleDeleteUser);
        saveUser = findViewById(R.id.saveUser);
        deleteUser = findViewById(R.id.deleteUser);

        // Retrieve user data from Intent
        originalUsername = getIntent().getStringExtra("USERNAME");
        String password = getIntent().getStringExtra("PASSWORD");
        String role = getIntent().getStringExtra("ROLE");
        String permissions = getIntent().getStringExtra("PERMISSIONS");
        boolean isActive = getIntent().getBooleanExtra("ACTIVE", false);
        boolean hasAccess = getIntent().getBooleanExtra("ACCESS", false);

        // Set initial values
        editUsername.setText(originalUsername);
        editPassword.setText(password);
        toggleActive.setChecked(isActive);
        toggleAccess.setChecked(hasAccess);
        setPermissions(permissions);

        // Back button click listener
        backButton.setOnClickListener(v -> finish());

        // Save button click listener
        saveUser.setOnClickListener(v -> updateUser());

        // Delete button click listener
        deleteUser.setOnClickListener(v -> deleteUser());
    }

    // Helper methods for toggles and permissions
    // This method does not work right currently
    // TODO: Fix the array reader, add more troubleshooting methods
    private void setPermissions(String permissions) {
        Log.d("ModifyUserActivity", "Permissions: " + permissions);
        if (permissions == null) return;
        // Set the toggles based on permissions
        String[] permissionArray = permissions.split(",");
        toggleModifyItems.setChecked(Arrays.asList(permissionArray).contains("MODIFY_ITEMS"));
        toggleDeleteItems.setChecked(Arrays.asList(permissionArray).contains("DELETE_ITEMS"));
        toggleModifyUsers.setChecked(Arrays.asList(permissionArray).contains("MODIFY_USERS"));
        toggleDeleteUsers.setChecked(Arrays.asList(permissionArray).contains("DELETE_USERS"));
    }

    private String getPermissions() {
        Log.d("ModifyUserActivity", "getPermissions called");
        Log.d("ModifyUserActivity", "toggleModifyItems: " + toggleModifyItems.isChecked());
        Log.d("ModifyUserActivity", "toggleDeleteItems: " + toggleDeleteItems.isChecked());
        Log.d("ModifyUserActivity", "toggleModifyUsers: " + toggleModifyUsers.isChecked());
        Log.d("ModifyUserActivity", "toggleDeleteUsers: " + toggleDeleteUsers.isChecked());
        // Get permissions based on the toggles
        StringBuilder permissions = new StringBuilder();
        if (toggleModifyItems.isChecked()) permissions.append("MODIFY_ITEMS,");
        if (toggleDeleteItems.isChecked()) permissions.append("DELETE_ITEMS,");
        if (toggleModifyUsers.isChecked()) permissions.append("MODIFY_USERS,");
        if (toggleDeleteUsers.isChecked()) permissions.append("DELETE_USERS,");
        // Remove the last comma
        if (permissions.length() > 0) permissions.setLength(permissions.length() - 1);
        return permissions.toString();
    }

    private void updateUser() {
        String username = editUsername.getText().toString();
        String password = editPassword.getText().toString();
        String permissions = getPermissions();
        boolean isUpdated = UserTableInterface.updateUser(username, password, "user", permissions.split(","));

        if (isUpdated) {
            Toast.makeText(this, "User updated successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to update user", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteUser() {
        boolean isDeleted = UserTableInterface.deleteUser(originalUsername);
        if (isDeleted) {
            Toast.makeText(this, "User deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to delete user", Toast.LENGTH_SHORT).show();
        }
    }
}
